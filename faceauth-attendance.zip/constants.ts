import { LivenessAction } from './types';

export const LIVENESS_ACTIONS = [
  LivenessAction.BLINK,
  LivenessAction.SMILE,
  LivenessAction.LOOK_LEFT,
  LivenessAction.LOOK_RIGHT,
  LivenessAction.OPEN_MOUTH
];

export const MODEL_NAME = 'gemini-3-flash-preview';

export const PLACEHOLDER_IMAGE = 'https://picsum.photos/400/300';