import React from 'react';

const Documentation: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto p-6 bg-white shadow-sm rounded-xl space-y-8">
      <header className="border-b pb-4">
        <h1 className="text-3xl font-bold text-gray-900">System Documentation</h1>
        <p className="text-gray-500 mt-2">AI-Powered Face Authentication & Attendance System</p>
      </header>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold text-gray-800">1. Model and Approach</h2>
        <div className="prose text-gray-600">
          <p>
            This system leverages <strong>Google's Gemini 3 Flash Preview</strong>, a multimodal large language model, to perform zero-shot face verification and liveness detection. Unlike traditional systems that use specialized embeddings (e.g., FaceNet, dlib) and separate liveness classifiers, this approach uses a holistic "Vision-to-Text" analysis.
          </p>
          <ul className="list-disc pl-5 space-y-2 mt-2">
            <li><strong>Face Verification:</strong> The model compares the facial structure of a "Live" image against a database of registered user images passed within the context window. It performs 1:N matching by analyzing visual features.</li>
            <li><strong>Liveness Detection:</strong> We employ a challenge-response mechanism. The user is asked to perform a random action (e.g., "Blink", "Smile"). Gemini verifies if the action in the image matches the prompt.</li>
            <li><strong>Spoof Prevention:</strong> The model is explicitly prompted to analyze the image for artifacts typical of spoofing attacks, such as screen moiré patterns, lack of depth, or flat lighting inconsistent with the environment.</li>
          </ul>
        </div>
      </section>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold text-gray-800">2. Training Process</h2>
        <div className="prose text-gray-600">
          <p>
            As a <strong>Zero-Shot</strong> implementation using a pre-trained Foundation Model, no explicit fine-tuning or training was performed for this specific dataset.
          </p>
          <p className="mt-2">
            The system relies on the generalization capabilities of Gemini, which has been pre-trained on a massive corpus of images and text. The "training" in this context refers to the prompt engineering designed to guide the model's attention to facial landmarks and specific spoofing artifacts.
          </p>
        </div>
      </section>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold text-gray-800">3. Accuracy Expectations</h2>
        <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
          <h3 className="font-semibold text-blue-800 mb-2">Estimated Metrics</h3>
          <ul className="list-disc pl-5 text-blue-700 space-y-1">
            <li><strong>Face Matching:</strong> ~90-95% accuracy for high-quality, well-lit frontal inputs.</li>
            <li><strong>Liveness Detection:</strong> High accuracy for obvious actions (smiling, blinking). Lower accuracy for subtle movements.</li>
            <li><strong>Latency:</strong> ~1-3 seconds per verification (dependent on API network speed).</li>
          </ul>
        </div>
      </section>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold text-gray-800">4. Known Failure Cases</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border p-4 rounded-lg">
                <h3 className="font-bold text-red-600">Extreme Lighting</h3>
                <p className="text-sm text-gray-600 mt-1">
                    Strong backlighting or very dim environments degrade the model's ability to see facial features, leading to false negatives.
                </p>
            </div>
            <div className="border p-4 rounded-lg">
                <h3 className="font-bold text-red-600">Large Database Scaling</h3>
                <p className="text-sm text-gray-600 mt-1">
                    Current implementation sends all registered faces in the context window. This works for demos (N &lt; 10) but will hit token limits or degrade accuracy for large user bases. Production systems should use vector search (embeddings) first.
                </p>
            </div>
            <div className="border p-4 rounded-lg">
                <h3 className="font-bold text-red-600">High-Quality Deepfakes</h3>
                <p className="text-sm text-gray-600 mt-1">
                    While basic screen attacks are detected, sophisticated AI-generated deepfakes on high-res displays might still fool the visual analysis without specialized depth sensors.
                </p>
            </div>
        </div>
      </section>
      
      <section className="space-y-4">
        <h2 className="text-2xl font-semibold text-gray-800">5. ML Limitations</h2>
        <p className="text-gray-600">
            Biometric systems are probabilistic, not deterministic. There is always a trade-off between False Acceptance Rate (FAR) and False Rejection Rate (FRR). This system prioritizes user convenience (low FRR) but may have higher FAR compared to enterprise hardware-based scanners.
        </p>
      </section>
    </div>
  );
};

export default Documentation;