import React, { useRef, useEffect, useState, useCallback } from 'react';

interface CameraViewProps {
  onCapture: (imageSrc: string) => void;
  isCapturing?: boolean;
  instruction?: string;
  overlayColor?: string;
}

const CameraView: React.FC<CameraViewProps> = ({ onCapture, isCapturing, instruction, overlayColor = 'border-indigo-500' }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [streamActive, setStreamActive] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const startCamera = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
            width: { ideal: 1280 },
            height: { ideal: 720 },
            facingMode: "user"
        } 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setStreamActive(true);
      }
    } catch (err) {
      console.error("Camera error:", err);
      setError("Unable to access camera. Please allow permissions.");
    }
  }, []);

  const stopCamera = useCallback(() => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
      setStreamActive(false);
    }
  }, []);

  useEffect(() => {
    startCamera();
    return () => stopCamera();
  }, [startCamera, stopCamera]);

  const capture = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');
      
      if (context) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        // Mirror the image to match user expectation
        context.translate(canvas.width, 0);
        context.scale(-1, 1);
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        const imageSrc = canvas.toDataURL('image/jpeg', 0.85);
        onCapture(imageSrc);
      }
    }
  };

  return (
    <div className="relative w-full max-w-lg mx-auto bg-black rounded-2xl overflow-hidden shadow-2xl">
      {/* Hidden Canvas for processing */}
      <canvas ref={canvasRef} className="hidden" />
      
      {/* Video Feed */}
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className={`w-full h-auto object-cover transform -scale-x-100 transition-opacity duration-500 ${streamActive ? 'opacity-100' : 'opacity-0'}`}
        onLoadedMetadata={() => setStreamActive(true)}
      />

      {/* Loading State */}
      {!streamActive && !error && (
        <div className="absolute inset-0 flex items-center justify-center text-white">
          <svg className="animate-spin h-8 w-8 mr-3 text-white" viewBox="0 0 24 24">
             <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
             <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          Initializing Camera...
        </div>
      )}

      {/* Error State */}
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-900 text-red-400 p-4 text-center">
          {error}
        </div>
      )}

      {/* Overlay UI */}
      {streamActive && (
        <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-4">
            
            {/* Top Instruction Bar */}
            <div className="w-full bg-black/50 backdrop-blur-sm text-white py-2 px-4 rounded-lg text-center font-medium shadow-lg animate-fade-in-down">
                {instruction || "Position your face in the center"}
            </div>

            {/* Face Frame */}
            <div className={`flex-grow flex items-center justify-center`}>
                 <div className={`w-64 h-64 border-2 ${overlayColor} rounded-full opacity-70 border-dashed`}></div>
            </div>

            {/* Capture Controls (Pointer events enabled for button) */}
            <div className="pointer-events-auto flex justify-center pb-4">
                <button
                    onClick={capture}
                    disabled={isCapturing}
                    className={`
                        w-16 h-16 rounded-full border-4 border-white flex items-center justify-center
                        focus:outline-none focus:ring-4 focus:ring-indigo-500 focus:ring-opacity-50
                        transform transition-all duration-200
                        ${isCapturing ? 'bg-gray-400 scale-90' : 'bg-red-500 hover:scale-105 active:scale-95'}
                    `}
                >
                  <div className="w-full h-full rounded-full border border-gray-900 opacity-20"></div>
                </button>
            </div>
        </div>
      )}
    </div>
  );
};

export default CameraView;