import React, { useState, useEffect, useCallback } from 'react';
import { AppView, User, AttendanceRecord, AttendanceType, LivenessAction, VerificationResult } from './types';
import { LIVENESS_ACTIONS } from './constants';
import * as storage from './services/storageService';
import * as gemini from './services/geminiService';
import CameraView from './components/CameraView';
import Documentation from './components/Documentation';
import { 
  UserPlus, 
  Clock, 
  FileText, 
  LogOut, 
  CheckCircle, 
  XCircle, 
  AlertTriangle,
  History,
  ShieldCheck,
  User as UserIcon,
  Home
} from 'lucide-react';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>(AppView.HOME);
  const [users, setUsers] = useState<User[]>([]);
  const [logs, setLogs] = useState<AttendanceRecord[]>([]);
  
  // Registration State
  const [regName, setRegName] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);
  
  // Attendance State
  const [attendanceType, setAttendanceType] = useState<AttendanceType>(AttendanceType.PUNCH_IN);
  const [challenge, setChallenge] = useState<LivenessAction>(LivenessAction.BLINK);
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationResult, setVerificationResult] = useState<VerificationResult | null>(null);

  useEffect(() => {
    setUsers(storage.getUsers());
    setLogs(storage.getAttendanceLogs());
  }, []);

  const handleRegister = async (imageSrc: string) => {
    if (!regName.trim()) {
      alert("Please enter a name first");
      return;
    }
    
    setIsRegistering(true);
    // In a real app, we might verify the face quality here too
    
    const newUser: User = {
      id: crypto.randomUUID(),
      name: regName,
      faceImage: imageSrc,
      registeredAt: new Date().toISOString()
    };
    
    storage.saveUser(newUser);
    setUsers(storage.getUsers());
    setIsRegistering(false);
    setRegName('');
    alert("User registered successfully!");
    setView(AppView.HOME);
  };

  const startAttendance = (type: AttendanceType) => {
    setAttendanceType(type);
    setVerificationResult(null);
    // Pick random challenge
    const randomAction = LIVENESS_ACTIONS[Math.floor(Math.random() * LIVENESS_ACTIONS.length)];
    setChallenge(randomAction);
    setView(AppView.ATTENDANCE);
  };

  const handleAttendanceCapture = async (imageSrc: string) => {
    setIsVerifying(true);
    setVerificationResult(null);

    const result = await gemini.verifyFace(imageSrc, users, challenge);
    
    setVerificationResult(result);
    setIsVerifying(false);

    if (result.match && result.userId && result.livenessConfirmed && !result.spoofDetected) {
      const user = users.find(u => u.id === result.userId);
      if (user) {
        const record: AttendanceRecord = {
          id: crypto.randomUUID(),
          userId: user.id,
          userName: user.name,
          timestamp: new Date().toISOString(),
          type: attendanceType,
          verificationConfidence: result.confidence
        };
        storage.logAttendance(record);
        setLogs(storage.getAttendanceLogs());
      }
    }
  };

  const renderHome = () => (
    <div className="flex flex-col items-center justify-center h-full space-y-8 p-6 animate-fade-in">
      <div className="text-center space-y-4">
        <div className="bg-indigo-100 p-4 rounded-full w-20 h-20 mx-auto flex items-center justify-center">
            <ShieldCheck className="w-10 h-10 text-indigo-600" />
        </div>
        <h1 className="text-4xl font-extrabold text-gray-900 tracking-tight">FaceAuth <span className="text-indigo-600">Access</span></h1>
        <p className="text-gray-500 max-w-md mx-auto">Secure, AI-powered biometric attendance system with liveness detection.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-lg">
        <button 
          onClick={() => startAttendance(AttendanceType.PUNCH_IN)}
          className="flex flex-col items-center p-6 bg-white border border-gray-200 rounded-2xl shadow-sm hover:shadow-md hover:border-indigo-300 transition-all group"
        >
          <div className="bg-green-100 p-3 rounded-xl mb-3 group-hover:bg-green-200 transition-colors">
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          <span className="font-semibold text-gray-800">Punch In</span>
        </button>

        <button 
          onClick={() => startAttendance(AttendanceType.PUNCH_OUT)}
          className="flex flex-col items-center p-6 bg-white border border-gray-200 rounded-2xl shadow-sm hover:shadow-md hover:border-indigo-300 transition-all group"
        >
          <div className="bg-orange-100 p-3 rounded-xl mb-3 group-hover:bg-orange-200 transition-colors">
            <LogOut className="w-8 h-8 text-orange-600" />
          </div>
          <span className="font-semibold text-gray-800">Punch Out</span>
        </button>

        <button 
          onClick={() => setView(AppView.REGISTER)}
          className="flex flex-col items-center p-6 bg-white border border-gray-200 rounded-2xl shadow-sm hover:shadow-md hover:border-indigo-300 transition-all group"
        >
          <div className="bg-blue-100 p-3 rounded-xl mb-3 group-hover:bg-blue-200 transition-colors">
            <UserPlus className="w-8 h-8 text-blue-600" />
          </div>
          <span className="font-semibold text-gray-800">Register Face</span>
        </button>

        <button 
          onClick={() => setView(AppView.HISTORY)}
          className="flex flex-col items-center p-6 bg-white border border-gray-200 rounded-2xl shadow-sm hover:shadow-md hover:border-indigo-300 transition-all group"
        >
          <div className="bg-purple-100 p-3 rounded-xl mb-3 group-hover:bg-purple-200 transition-colors">
            <History className="w-8 h-8 text-purple-600" />
          </div>
          <span className="font-semibold text-gray-800">View Logs</span>
        </button>
      </div>
      
       <button 
        onClick={() => setView(AppView.DOCS)}
        className="text-sm text-gray-500 hover:text-indigo-600 flex items-center gap-2 mt-8"
      >
        <FileText className="w-4 h-4" />
        Read Documentation
      </button>
    </div>
  );

  const renderRegister = () => (
    <div className="max-w-xl mx-auto w-full p-4">
      <div className="mb-6 text-center">
        <h2 className="text-2xl font-bold text-gray-900">Register New User</h2>
        <p className="text-gray-500">Enter name and look at the camera</p>
      </div>
      
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
        <input 
          type="text" 
          value={regName}
          onChange={(e) => setRegName(e.target.value)}
          placeholder="e.g. John Doe"
          className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
        />
      </div>

      <div className="mb-6">
        <CameraView 
          onCapture={handleRegister} 
          isCapturing={isRegistering}
          instruction={regName ? `Hi ${regName}, look at the camera` : "Enter name above first"}
          overlayColor="border-blue-500"
        />
      </div>

      <button onClick={() => setView(AppView.HOME)} className="w-full py-3 text-gray-500 hover:bg-gray-100 rounded-lg transition-colors">
        Cancel
      </button>
    </div>
  );

  const renderAttendance = () => (
    <div className="max-w-xl mx-auto w-full p-4">
       <div className="mb-4 text-center">
        <h2 className="text-2xl font-bold text-gray-900">{attendanceType === AttendanceType.PUNCH_IN ? 'Punch In' : 'Punch Out'}</h2>
        <p className="text-gray-500">Security Check</p>
      </div>

      {!verificationResult ? (
        <div className="space-y-6 animate-fade-in">
            <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-4 flex items-center justify-between">
                <div>
                    <span className="text-xs font-bold text-indigo-500 uppercase tracking-wider">Required Action</span>
                    <p className="text-lg font-semibold text-indigo-900 mt-1">{challenge}</p>
                </div>
                <div className="bg-white p-2 rounded-lg shadow-sm">
                    {/* Visual hint for action could go here */}
                    <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center">
                        <UserIcon className="w-5 h-5 text-indigo-600" />
                    </div>
                </div>
            </div>

            <CameraView 
                onCapture={handleAttendanceCapture} 
                isCapturing={isVerifying}
                instruction={`Please: ${challenge}`}
                overlayColor="border-green-500"
            />
            
             {isVerifying && (
                <div className="text-center p-4">
                    <p className="text-indigo-600 font-medium animate-pulse">Verifying identity & liveness...</p>
                </div>
            )}
             <button onClick={() => setView(AppView.HOME)} className="w-full py-3 text-gray-500 hover:bg-gray-100 rounded-lg transition-colors">
                Cancel
            </button>
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden animate-scale-up">
            <div className={`p-6 text-center ${verificationResult.match && verificationResult.livenessConfirmed && !verificationResult.spoofDetected ? 'bg-green-50' : 'bg-red-50'}`}>
                {verificationResult.match && verificationResult.livenessConfirmed && !verificationResult.spoofDetected ? (
                    <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <CheckCircle className="w-10 h-10 text-green-600" />
                    </div>
                ) : (
                    <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <XCircle className="w-10 h-10 text-red-600" />
                    </div>
                )}
                
                <h3 className="text-2xl font-bold text-gray-900 mb-1">
                    {verificationResult.match && verificationResult.livenessConfirmed && !verificationResult.spoofDetected ? 'Access Granted' : 'Access Denied'}
                </h3>
                <p className="text-gray-600">{verificationResult.reason}</p>
            </div>

            <div className="p-6 space-y-4">
                <div className="flex justify-between items-center py-2 border-b border-gray-100">
                    <span className="text-gray-500">Identity Match</span>
                    <span className={`font-medium ${verificationResult.match ? 'text-green-600' : 'text-red-600'}`}>
                        {verificationResult.match ? `Matched (${Math.round(verificationResult.confidence * 100)}%)` : 'Unknown'}
                    </span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-gray-100">
                    <span className="text-gray-500">Liveness Check</span>
                    <span className={`font-medium ${verificationResult.livenessConfirmed ? 'text-green-600' : 'text-red-600'}`}>
                        {verificationResult.livenessConfirmed ? 'Passed' : 'Failed Action'}
                    </span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-gray-100">
                    <span className="text-gray-500">Spoof Detection</span>
                    <span className={`font-medium ${!verificationResult.spoofDetected ? 'text-green-600' : 'text-red-600'}`}>
                        {!verificationResult.spoofDetected ? 'Clean' : 'Spoof Detected'}
                    </span>
                </div>
                
                <button 
                    onClick={() => setView(AppView.HOME)}
                    className="w-full mt-4 bg-gray-900 text-white py-3 rounded-xl font-medium hover:bg-gray-800 transition-all shadow-lg shadow-gray-200"
                >
                    Return Home
                </button>
            </div>
        </div>
      )}
    </div>
  );

  const renderHistory = () => (
    <div className="max-w-2xl mx-auto w-full p-4 h-full flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Attendance Logs</h2>
        <button onClick={() => setView(AppView.HOME)} className="p-2 hover:bg-gray-100 rounded-full">
            <XCircle className="w-6 h-6 text-gray-400" />
        </button>
      </div>

      <div className="flex-grow overflow-auto bg-white rounded-2xl shadow-sm border border-gray-200 p-2">
        {logs.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-gray-400">
                <Clock className="w-12 h-12 mb-3 opacity-20" />
                <p>No records found</p>
            </div>
        ) : (
            <table className="w-full text-left border-collapse">
                <thead className="sticky top-0 bg-gray-50 z-10">
                    <tr>
                        <th className="p-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">User</th>
                        <th className="p-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Type</th>
                        <th className="p-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Time</th>
                        <th className="p-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Conf.</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                    {logs.map(log => (
                        <tr key={log.id} className="hover:bg-gray-50 transition-colors">
                            <td className="p-4 font-medium text-gray-900">{log.userName}</td>
                            <td className="p-4">
                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${log.type === AttendanceType.PUNCH_IN ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'}`}>
                                    {log.type === AttendanceType.PUNCH_IN ? 'IN' : 'OUT'}
                                </span>
                            </td>
                            <td className="p-4 text-gray-500 text-sm">
                                {new Date(log.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                <div className="text-xs text-gray-400">{new Date(log.timestamp).toLocaleDateString()}</div>
                            </td>
                            <td className="p-4 text-gray-500 text-sm">{(log.verificationConfidence * 100).toFixed(0)}%</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        )}
      </div>
    </div>
  );

  const renderDocs = () => (
      <div className="h-full overflow-auto p-4 bg-gray-50">
          <div className="max-w-4xl mx-auto mb-4">
               <button onClick={() => setView(AppView.HOME)} className="flex items-center text-gray-500 hover:text-gray-900">
                  <Home className="w-4 h-4 mr-2" /> Back to App
               </button>
          </div>
          <Documentation />
      </div>
  )

  return (
    <div className="h-screen w-full bg-gray-50 overflow-hidden relative">
      <main className="h-full w-full">
        {view === AppView.HOME && renderHome()}
        {view === AppView.REGISTER && renderRegister()}
        {view === AppView.ATTENDANCE && renderAttendance()}
        {view === AppView.HISTORY && renderHistory()}
        {view === AppView.DOCS && renderDocs()}
      </main>
    </div>
  );
};

export default App;