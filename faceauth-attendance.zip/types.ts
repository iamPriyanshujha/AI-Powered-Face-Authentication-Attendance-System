export interface User {
  id: string;
  name: string;
  faceImage: string; // Base64
  registeredAt: string;
}

export enum AttendanceType {
  PUNCH_IN = 'PUNCH_IN',
  PUNCH_OUT = 'PUNCH_OUT'
}

export interface AttendanceRecord {
  id: string;
  userId: string;
  userName: string;
  timestamp: string;
  type: AttendanceType;
  verificationConfidence: number;
}

export interface VerificationResult {
  match: boolean;
  userId?: string;
  confidence: number;
  livenessConfirmed: boolean;
  spoofDetected: boolean;
  reason: string;
}

export enum AppView {
  HOME = 'HOME',
  REGISTER = 'REGISTER',
  ATTENDANCE = 'ATTENDANCE',
  HISTORY = 'HISTORY',
  DOCS = 'DOCS'
}

export enum LivenessAction {
  BLINK = 'Blink your eyes',
  SMILE = 'Smile widely',
  LOOK_LEFT = 'Turn head slightly left',
  LOOK_RIGHT = 'Turn head slightly right',
  OPEN_MOUTH = 'Open your mouth'
}