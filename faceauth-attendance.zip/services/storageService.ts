import { User, AttendanceRecord } from '../types';

const USERS_KEY = 'faceauth_users';
const ATTENDANCE_KEY = 'faceauth_logs';

export const getUsers = (): User[] => {
  const data = localStorage.getItem(USERS_KEY);
  return data ? JSON.parse(data) : [];
};

export const saveUser = (user: User): void => {
  const users = getUsers();
  users.push(user);
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
};

export const getAttendanceLogs = (): AttendanceRecord[] => {
  const data = localStorage.getItem(ATTENDANCE_KEY);
  return data ? JSON.parse(data) : [];
};

export const logAttendance = (record: AttendanceRecord): void => {
  const logs = getAttendanceLogs();
  logs.unshift(record); // Add to beginning
  localStorage.setItem(ATTENDANCE_KEY, JSON.stringify(logs));
};

export const clearData = () => {
  localStorage.removeItem(USERS_KEY);
  localStorage.removeItem(ATTENDANCE_KEY);
}