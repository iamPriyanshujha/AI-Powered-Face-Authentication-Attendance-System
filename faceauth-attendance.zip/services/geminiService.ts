import { GoogleGenAI, Type } from "@google/genai";
import { User, VerificationResult, LivenessAction } from '../types';
import { MODEL_NAME } from '../constants';

const apiKey = process.env.API_KEY;

if (!apiKey) {
  console.error("API_KEY is missing from environment variables.");
}

const ai = new GoogleGenAI({ apiKey: apiKey || 'MISSING_KEY' });

// Helper to strip data:image/jpeg;base64, prefix
const cleanBase64 = (data: string) => {
  return data.replace(/^data:image\/(png|jpeg|webp);base64,/, "");
};

/**
 * Verifies a live face against a list of registered users.
 * This function performs 1:N identification (for small N) and liveness check.
 */
export const verifyFace = async (
  liveImage: string,
  users: User[],
  requiredAction: LivenessAction
): Promise<VerificationResult> => {
  
  if (users.length === 0) {
    return {
      match: false,
      confidence: 0,
      livenessConfirmed: false,
      spoofDetected: false,
      reason: "No registered users found."
    };
  }

  // We will construct a multimodal prompt.
  // Part 1: The Live Image
  // Part 2..N: The Registered Images with ID labels
  // Prompt: Instructions
  
  const liveImagePart = {
    inlineData: {
      data: cleanBase64(liveImage),
      mimeType: 'image/jpeg'
    }
  };

  const userParts = users.map((u, index) => ({
    inlineData: {
      data: cleanBase64(u.faceImage),
      mimeType: 'image/jpeg'
    }
  }));

  const promptText = `
    You are a high-security biometric authentication system.
    
    I have provided multiple images.
    The FIRST image is the "LIVE_INPUT" from a camera.
    The subsequent images are "REGISTERED_USER_${0}" to "REGISTERED_USER_${users.length - 1}".
    
    Your task is to perform three critical checks on the "LIVE_INPUT":

    1. **Identification**: Does the person in "LIVE_INPUT" match ANY of the "REGISTERED_USER" images? 
       Compare facial features, structure, and landmarks carefully.
    
    2. **Liveness Action Verification**: The user was instructed to perform this specific action: "${requiredAction}".
       Is the person in "LIVE_INPUT" clearly performing this action?
       
    3. **Spoof Detection**: Does "LIVE_INPUT" look like a genuine human face captured by a webcam?
       Check for signs of:
       - Photos of screens (moiré patterns, pixel grids).
       - Photos of photos (flat depth, glossy reflections).
       - Unnatural static expressions inconsistent with the requested action.

    Return the result in strict JSON format:
    {
      "match": boolean, (true if identity matches a registered user)
      "matchedUserIndex": number | null, (the index 0-${users.length - 1} of the matching registered user, or null)
      "confidence": number, (0.0 to 1.0, how sure are you of the identity match)
      "livenessConfirmed": boolean, (true if the specific action is performed)
      "spoofDetected": boolean, (true if it looks fake/spoofed)
      "reason": string (short explanation of your decision)
    }
  `;

  try {
    // Construct parts array: [LiveImage, ...RegisteredImages, Prompt]
    const parts = [liveImagePart, ...userParts, { text: promptText }];

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: { parts },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
            type: Type.OBJECT,
            properties: {
                match: { type: Type.BOOLEAN },
                matchedUserIndex: { type: Type.INTEGER, nullable: true },
                confidence: { type: Type.NUMBER },
                livenessConfirmed: { type: Type.BOOLEAN },
                spoofDetected: { type: Type.BOOLEAN },
                reason: { type: Type.STRING }
            }
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("Empty response from AI");

    const result = JSON.parse(text);

    let userId: string | undefined;
    if (result.match && result.matchedUserIndex !== null && result.matchedUserIndex >= 0 && result.matchedUserIndex < users.length) {
        userId = users[result.matchedUserIndex].id;
    }

    return {
      match: result.match,
      userId,
      confidence: result.confidence,
      livenessConfirmed: result.livenessConfirmed,
      spoofDetected: result.spoofDetected,
      reason: result.reason
    };

  } catch (error) {
    console.error("Verification failed", error);
    return {
      match: false,
      confidence: 0,
      livenessConfirmed: false,
      spoofDetected: false,
      reason: "System error during verification."
    };
  }
};